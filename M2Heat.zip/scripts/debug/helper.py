class network_t():
    def __init__(self):
        pass
    def send_shop_search_info_sub(self, index):
        pass

network = network_t()