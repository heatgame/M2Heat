def trace(s):
	print("trace: " + s)