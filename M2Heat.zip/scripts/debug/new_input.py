def get_string():
	try:
		return input()
	except:
		return raw_input()
